export type JikanAnime = {
  malId: number
  title: string
  titleEnglish: string | null
  image: string | null
  episodes: number | null
  score: number | null
  synopsis: string | null
  genres: string[]
  type: string | null
  year: number | null
  status: string | null
  url: string
}

/** `undefined` = not fetched yet, `null` = no match or request failed */
export type JikanCache = Record<string, JikanAnime | null>

const CACHE_KEY = 'xenoani-jikan-v1'
const REQUEST_GAP_MS = 350
const EMPTY: JikanCache = {}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

let persisted: JikanCache = {}
let failed: Record<string, null> = {}
let snapshot: JikanCache = EMPTY
let hydrated = false
let running = false
const listeners = new Set<() => void>()

function hydrate() {
  if (hydrated || typeof window === 'undefined') return
  hydrated = true
  try {
    persisted = JSON.parse(window.localStorage.getItem(CACHE_KEY) ?? '{}')
  } catch {
    persisted = {}
  }
  snapshot = { ...persisted }
}

function emit() {
  snapshot = { ...persisted, ...failed }
  try {
    window.localStorage.setItem(CACHE_KEY, JSON.stringify(persisted))
  } catch {
    // Storage full or blocked; in-memory results still render.
  }
  listeners.forEach((listener) => listener())
}

type JikanResponse = {
  data?: Array<{
    mal_id: number
    url: string
    title: string
    title_english: string | null
    images?: { webp?: { large_image_url?: string }; jpg?: { large_image_url?: string } }
    episodes: number | null
    score: number | null
    synopsis: string | null
    genres?: { name: string }[]
    themes?: { name: string }[]
    type: string | null
    year: number | null
    status: string | null
    aired?: { prop?: { from?: { year?: number | null } } }
  }>
}

let jikanUnreachable = false

async function fetchTitle(title: string): Promise<JikanAnime | null | 'error'> {
  const result = jikanUnreachable ? 'error' : await fetchFromJikan(title)
  if (result !== 'error') return result
  return fetchFromFallback(title)
}

async function fetchFromFallback(title: string, attempt = 0): Promise<JikanAnime | null | 'error'> {
  try {
    const res = await fetch(`/api/lookup?q=${encodeURIComponent(title)}`)
    if (res.status === 429 && attempt < 3) {
      await sleep(2000 * (attempt + 1))
      return fetchFromFallback(title, attempt + 1)
    }
    if (!res.ok) return 'error'
    const json = (await res.json()) as { anime: JikanAnime | null }
    return json.anime
  } catch {
    return 'error'
  }
}

async function fetchFromJikan(title: string, attempt = 0): Promise<JikanAnime | null | 'error'> {
  try {
    const res = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(title)}&limit=1`, {
      signal: AbortSignal.timeout(8000),
    })
    if (res.status === 429 && attempt < 3) {
      await sleep(1200 * (attempt + 1))
      return fetchFromJikan(title, attempt + 1)
    }
    if (!res.ok) return 'error'
    const json = (await res.json()) as JikanResponse
    const a = json.data?.[0]
    if (!a) return null
    return {
      malId: a.mal_id,
      title: a.title,
      titleEnglish: a.title_english,
      image: a.images?.webp?.large_image_url ?? a.images?.jpg?.large_image_url ?? null,
      episodes: a.episodes,
      score: a.score,
      synopsis: a.synopsis?.replace(/\s*\[Written by MAL Rewrite\]\s*$/, '') ?? null,
      genres: [...(a.genres ?? []), ...(a.themes ?? [])].map((g) => g.name),
      type: a.type,
      year: a.year ?? a.aired?.prop?.from?.year ?? null,
      status: a.status,
      url: a.url,
    }
  } catch {
    // Network-level failure (blocked, offline, timeout): skip Jikan for the rest of this session.
    jikanUnreachable = true
    return 'error'
  }
}

export async function prefetchTitles(titles: string[]) {
  hydrate()
  if (running) return
  running = true
  for (const title of titles) {
    if (title in persisted || title in failed) continue
    const result = await fetchTitle(title)
    if (result === 'error') failed[title] = null
    else persisted[title] = result
    emit()
    await sleep(REQUEST_GAP_MS)
  }
  running = false
}

export function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

export function getSnapshot() {
  hydrate()
  return snapshot
}

export function getServerSnapshot() {
  return EMPTY
}

export function retryFailed(titles: string[]) {
  failed = {}
  emit()
  void prefetchTitles(titles)
}
