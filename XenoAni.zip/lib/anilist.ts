export type Anime = {
  id: number
  title: string
  englishTitle: string | null
  cover: string
  banner: string | null
  color: string | null
  score: number | null
  episodes: number | null
  format: string | null
  year: number | null
  genres: string[]
  description: string
}

type AniListMedia = {
  id: number
  title: { romaji: string | null; english: string | null }
  coverImage: { extraLarge: string | null; large: string | null; color: string | null }
  bannerImage: string | null
  averageScore: number | null
  episodes: number | null
  format: string | null
  seasonYear: number | null
  genres: string[] | null
  description: string | null
}

const ANILIST_URL = 'https://graphql.anilist.co'

const MEDIA_FIELDS = `
  id
  title { romaji english }
  coverImage { extraLarge large color }
  bannerImage
  averageScore
  episodes
  format
  seasonYear
  genres
  description(asHtml: false)
`

function stripHtml(text: string) {
  return text
    .replace(/<br\s*\/?>/gi, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

function toAnime(media: AniListMedia): Anime {
  return {
    id: media.id,
    title: media.title.english ?? media.title.romaji ?? 'Untitled',
    englishTitle: media.title.english,
    cover: media.coverImage.extraLarge ?? media.coverImage.large ?? '',
    banner: media.bannerImage,
    color: media.coverImage.color,
    score: media.averageScore,
    episodes: media.episodes,
    format: media.format,
    year: media.seasonYear,
    genres: media.genres ?? [],
    description: media.description ? stripHtml(media.description) : '',
  }
}

async function queryMedia(
  sort: string,
  perPage: number,
  extra = '',
  variables: Record<string, unknown> = {},
  revalidate = 3600,
): Promise<Anime[]> {
  const query = `
    query ($perPage: Int${'search' in variables ? ', $search: String' : ''}) {
      Page(page: 1, perPage: $perPage) {
        media(type: ANIME, sort: [${sort}], isAdult: false ${extra}) {
          ${MEDIA_FIELDS}
        }
      }
    }
  `
  try {
    const res = await fetch(ANILIST_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ query, variables: { perPage, ...variables } }),
      next: { revalidate },
    })
    if (!res.ok) return []
    const json = (await res.json()) as { data?: { Page: { media: AniListMedia[] } } }
    return (json.data?.Page.media ?? []).map(toAnime).filter((a) => a.cover)
  } catch {
    return []
  }
}

export function getTrending(limit = 10) {
  return queryMedia('TRENDING_DESC', limit)
}

export function getTopRated(limit = 10) {
  return queryMedia('SCORE_DESC', limit)
}

export function getPopular(limit = 12) {
  return queryMedia('POPULARITY_DESC', limit)
}

export function searchAnime(search: string, limit = 18) {
  return queryMedia('SEARCH_MATCH', limit, ', search: $search', { search }, 300)
}
