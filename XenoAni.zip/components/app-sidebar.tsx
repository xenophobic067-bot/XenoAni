'use client'

import { Check, Clock, LayoutGrid, Library, Play, Plus, Search, Sparkles } from 'lucide-react'
import type { LibraryStatus } from '@/hooks/use-library'
import { cn } from '@/lib/utils'

export type View = 'library' | 'overview' | 'find' | LibraryStatus

type AppSidebarProps = {
  view: View
  onNavigate: (view: View) => void
  counts: Record<LibraryStatus, number>
}

const DISCOVER = [
  { view: 'library' as const, label: 'Library', icon: Library },
  { view: 'overview' as const, label: 'Overview', icon: LayoutGrid },
  { view: 'find' as const, label: 'Find anime', icon: Search },
]

const LIBRARY = [
  { view: 'watching' as const, label: 'Watching', icon: Play, color: 'text-primary' },
  { view: 'plan' as const, label: 'Plan to Watch', icon: Clock, color: 'text-chart-2' },
  { view: 'completed' as const, label: 'Completed', icon: Check, color: 'text-chart-3' },
]

export function AppSidebar({ view, onNavigate, counts }: AppSidebarProps) {
  const total = counts.watching + counts.plan + counts.completed

  const itemClass = (active: boolean) =>
    cn(
      'relative flex h-10 w-full items-center gap-3 rounded-lg px-3 text-sm transition-colors',
      active
        ? 'bg-sidebar-accent text-foreground before:absolute before:inset-y-1.5 before:left-0 before:w-0.5 before:rounded-full before:bg-primary'
        : 'text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground',
    )

  return (
    <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-sidebar-border bg-sidebar p-4 lg:flex">
      <div className="flex items-center gap-2.5 px-2 py-2">
        <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Sparkles className="size-5" aria-hidden="true" />
        </span>
        <span className="text-xl font-semibold">
          Xeno<span className="text-primary">Ani</span>
        </span>
      </div>

      <nav aria-label="Main" className="mt-8 flex flex-col gap-6">
        <div className="flex flex-col gap-1">
          <p className="px-3 pb-2 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">Discover</p>
          {DISCOVER.map(({ view: v, label, icon: Icon }) => (
            <button
              key={v}
              type="button"
              onClick={() => onNavigate(v)}
              aria-current={view === v ? 'page' : undefined}
              className={itemClass(view === v)}
            >
              <Icon className="size-4" aria-hidden="true" />
              {label}
            </button>
          ))}
          <button type="button" onClick={() => onNavigate('find')} className={itemClass(false)}>
            <Plus className="size-4" aria-hidden="true" />
            Add anime
          </button>
        </div>

        <div className="flex flex-col gap-1">
          <p className="px-3 pb-2 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">My library</p>
          {LIBRARY.map(({ view: v, label, icon: Icon, color }) => (
            <button
              key={v}
              type="button"
              onClick={() => onNavigate(v)}
              aria-current={view === v ? 'page' : undefined}
              className={itemClass(view === v)}
            >
              <Icon className={cn('size-4', color)} aria-hidden="true" />
              <span className="flex-1 text-left">{label}</span>
              <span className="font-mono text-xs text-muted-foreground">{counts[v]}</span>
            </button>
          ))}
        </div>
      </nav>

      <div className="mt-auto flex flex-col gap-3">
        <div className="flex items-center gap-3 rounded-xl border border-sidebar-border p-3">
          <span className="flex size-8 items-center justify-center rounded-full bg-chart-2 text-sm font-semibold text-primary-foreground">
            N
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{"Naitik's library"}</p>
            <p className="text-xs text-muted-foreground">{total} titles saved</p>
          </div>
        </div>
        <p className="px-2 font-mono text-[11px] text-muted-foreground">XenoAni · powered by AniList</p>
      </div>
    </aside>
  )
}
