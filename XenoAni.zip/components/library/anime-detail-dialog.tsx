'use client'

import Image from 'next/image'
import { ExternalLink, Star } from 'lucide-react'
import type { JikanAnime } from '@/lib/jikan'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'

type AnimeDetailDialogProps = {
  anime: JikanAnime | null
  listTitle: string | null
  onClose: () => void
}

export function AnimeDetailDialog({ anime, listTitle, onClose }: AnimeDetailDialogProps) {
  return (
    <Dialog open={!!anime} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[88dvh] overflow-y-auto p-0 sm:max-w-2xl">
        {anime && (
          <div className="flex flex-col sm:flex-row">
            <div className="relative aspect-[16/10] w-full shrink-0 overflow-hidden bg-card sm:aspect-[2/3] sm:w-56">
              {anime.image && (
                <Image
                  src={anime.image || '/placeholder.svg'}
                  alt={`${anime.titleEnglish ?? anime.title} poster`}
                  fill
                  sizes="(min-width: 640px) 224px, 100vw"
                  className="object-cover object-top"
                />
              )}
            </div>

            <div className="flex min-w-0 flex-1 flex-col gap-4 p-5 sm:p-6">
              <DialogHeader className="gap-1 text-left">
                <DialogTitle className="pr-6 text-xl leading-tight">{listTitle ?? anime.titleEnglish ?? anime.title}</DialogTitle>
                <DialogDescription className="text-xs">{anime.title}</DialogDescription>
              </DialogHeader>

              <dl className="grid grid-cols-3 gap-2">
                <Stat label="Score">
                  <span className="flex items-center gap-1">
                    <Star className="size-3.5 fill-primary text-primary" aria-hidden="true" />
                    {anime.score?.toFixed(2) ?? '—'}
                  </span>
                </Stat>
                <Stat label="Episodes">{anime.episodes ?? '?'}</Stat>
                <Stat label={anime.type ?? 'Type'}>{anime.year ?? '—'}</Stat>
              </dl>

              {anime.genres.length > 0 && (
                <ul className="flex flex-wrap gap-1.5" aria-label="Genres">
                  {anime.genres.map((g) => (
                    <li key={g} className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-xs text-primary">
                      {g}
                    </li>
                  ))}
                </ul>
              )}

              <p className="text-sm leading-relaxed text-muted-foreground">{anime.synopsis ?? 'No synopsis available.'}</p>

              <a
                href={anime.url}
                target="_blank"
                rel="noreferrer"
                className="mt-auto inline-flex items-center gap-1.5 self-start text-xs text-primary hover:underline"
              >
                View on MyAnimeList
                <ExternalLink className="size-3.5" aria-hidden="true" />
              </a>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function Stat({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border bg-card px-3 py-2">
      <dt className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="mt-0.5 text-sm font-semibold">{children}</dd>
    </div>
  )
}
