import Image from 'next/image'
import { ImageOff, Star } from 'lucide-react'
import type { JikanAnime } from '@/lib/jikan'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

type PosterCardProps = {
  title: string
  anime: JikanAnime | null | undefined
  rank?: number
  onOpen: () => void
}

export function PosterCard({ title, anime, rank, onOpen }: PosterCardProps) {
  if (anime === undefined) {
    return (
      <div className="w-28 shrink-0 snap-start sm:w-36 lg:w-40" aria-hidden="true">
        <Skeleton className="aspect-[2/3] w-full rounded-lg" />
        <Skeleton className="mt-2 h-3.5 w-4/5" />
        <Skeleton className="mt-1.5 h-3 w-1/2" />
      </div>
    )
  }

  return (
    <button
      type="button"
      onClick={onOpen}
      disabled={!anime}
      className="group w-28 shrink-0 snap-start text-left outline-none sm:w-36 lg:w-40"
    >
      <span className="relative block aspect-[2/3] overflow-hidden rounded-lg bg-card ring-1 ring-border transition group-hover:ring-primary group-focus-visible:ring-2 group-focus-visible:ring-primary">
        {anime?.image ? (
          <Image
            src={anime.image || '/placeholder.svg'}
            alt={`${anime.titleEnglish ?? anime.title} poster`}
            fill
            sizes="160px"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <span className="flex size-full flex-col items-center justify-center gap-2 p-3 text-center text-xs text-muted-foreground">
            <ImageOff className="size-5" aria-hidden="true" />
            Not found
          </span>
        )}

        {rank !== undefined && (
          <span
            className={cn(
              'absolute left-0 top-0 rounded-br-lg px-2 py-1 font-mono text-xs font-bold',
              rank <= 3 ? 'bg-primary text-primary-foreground' : 'bg-background/85 text-primary backdrop-blur',
            )}
          >
            #{rank}
          </span>
        )}

        {anime?.score != null && (
          <span className="absolute bottom-1.5 right-1.5 flex items-center gap-1 rounded-md bg-background/85 px-1.5 py-0.5 font-mono text-[11px] backdrop-blur">
            <Star className="size-3 fill-primary text-primary" aria-hidden="true" />
            {anime.score.toFixed(1)}
          </span>
        )}
      </span>

      <span className="mt-2 line-clamp-2 text-xs font-medium leading-snug sm:text-sm">{title}</span>
      {anime && (
        <span className="mt-0.5 block font-mono text-[11px] text-muted-foreground">
          {[anime.type, anime.episodes ? `${anime.episodes} ep` : null].filter(Boolean).join(' · ') || '—'}
        </span>
      )}
    </button>
  )
}
