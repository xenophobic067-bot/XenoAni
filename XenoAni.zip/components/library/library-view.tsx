'use client'

import { useState } from 'react'
import { RotateCw } from 'lucide-react'
import { ALL_TITLES, SHELVES } from '@/lib/watchlist'
import { useJikan } from '@/hooks/use-jikan'
import { GenreShelf } from '@/components/library/genre-shelf'
import { AnimeDetailDialog } from '@/components/library/anime-detail-dialog'

export function LibraryView({ query }: { query: string }) {
  const { cache, loaded, failed, total, retry } = useJikan(ALL_TITLES)
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({})
  const [selected, setSelected] = useState<string | null>(null)

  const needle = query.toLowerCase()
  const matches = (title: string) => {
    if (!needle) return true
    const a = cache[title]
    return [title, a?.title, a?.titleEnglish].some((t) => t?.toLowerCase().includes(needle))
  }

  const shelves = SHELVES.map((shelf) => ({ shelf, titles: shelf.titles.filter(matches) })).filter(
    ({ titles }) => titles.length > 0,
  )
  const progress = Math.round((loaded / total) * 100)

  return (
    <div className="flex flex-col gap-2">
      {loaded < total ? (
        <div className="flex flex-col gap-2 rounded-xl border bg-card p-4" role="status">
          <div className="flex items-center justify-between text-xs">
            <span>Fetching posters from MyAnimeList</span>
            <span className="font-mono text-muted-foreground">
              {loaded}/{total}
            </span>
          </div>
          <div className="h-1 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-[11px] text-muted-foreground">First load only — results are saved on this device.</p>
        </div>
      ) : (
        failed > 0 && (
          <div className="flex items-center justify-between gap-3 rounded-xl border bg-card p-4 text-xs">
            <span>{failed} titles could not be loaded.</span>
            <button type="button" onClick={retry} className="flex items-center gap-1.5 text-primary hover:underline">
              <RotateCw className="size-3.5" aria-hidden="true" />
              Retry
            </button>
          </div>
        )
      )}

      {shelves.length === 0 && (
        <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          {`No titles match "${query}".`}
        </p>
      )}

      {shelves.map(({ shelf, titles }) => (
        <GenreShelf
          key={shelf.id}
          shelf={shelf}
          titles={titles}
          cache={cache}
          open={!!needle || !collapsed[shelf.id]}
          onToggle={() => setCollapsed((c) => ({ ...c, [shelf.id]: !c[shelf.id] }))}
          onOpenTitle={setSelected}
        />
      ))}

      <AnimeDetailDialog
        anime={selected ? (cache[selected] ?? null) : null}
        listTitle={selected}
        onClose={() => setSelected(null)}
      />
    </div>
  )
}
