import { ChevronDown } from 'lucide-react'
import type { JikanCache } from '@/lib/jikan'
import type { Shelf } from '@/lib/watchlist'
import { PosterCard } from '@/components/library/poster-card'
import { cn } from '@/lib/utils'

type GenreShelfProps = {
  shelf: Shelf
  titles: string[]
  cache: JikanCache
  open: boolean
  onToggle: () => void
  onOpenTitle: (title: string) => void
}

export function GenreShelf({ shelf, titles, cache, open, onToggle, onOpenTitle }: GenreShelfProps) {
  const panelId = `shelf-${shelf.id}`

  return (
    <section aria-labelledby={`${panelId}-heading`} className="border-b pb-5 last:border-b-0">
      <h2 id={`${panelId}-heading`}>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          aria-controls={panelId}
          className="flex w-full items-center gap-3 py-3 text-left outline-none focus-visible:text-primary"
        >
          {shelf.ranked && <span className="h-5 w-1 rounded-full bg-primary" aria-hidden="true" />}
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="truncate text-lg font-semibold sm:text-xl">{shelf.title}</span>
            {shelf.subtitle && <span className="text-xs font-normal text-muted-foreground">{shelf.subtitle}</span>}
          </span>
          <span className="font-mono text-xs text-muted-foreground">{titles.length}</span>
          <ChevronDown
            className={cn('size-5 text-muted-foreground transition-transform', !open && '-rotate-90')}
            aria-hidden="true"
          />
        </button>
      </h2>

      <div id={panelId} hidden={!open}>
        <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2 pt-1 [scrollbar-width:thin] sm:-mx-8 sm:gap-4 sm:px-8 lg:mx-0 lg:px-0">
          {titles.map((title) => (
            <PosterCard
              key={title}
              title={title}
              anime={cache[title]}
              rank={shelf.ranked ? shelf.titles.indexOf(title) + 1 : undefined}
              onOpen={() => onOpenTitle(title)}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
