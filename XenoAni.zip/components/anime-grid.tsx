'use client'

import type { Anime } from '@/lib/anilist'
import type { LibraryStatus } from '@/hooks/use-library'
import { AnimeCard } from '@/components/anime-card'

type AnimeGridProps = {
  title?: string
  items: Anime[]
  ranked?: boolean
  statusOf: (id: number) => LibraryStatus | null
  onStatusChange: (anime: Anime, status: LibraryStatus | null) => void
  emptyMessage?: string
}

export function AnimeGrid({ title, items, ranked, statusOf, onStatusChange, emptyMessage }: AnimeGridProps) {
  return (
    <section aria-label={title} className="flex flex-col gap-4">
      {title && (
        <h2 className="text-xl font-medium">
          {title} <span className="font-mono text-sm text-muted-foreground">· {items.length}</span>
        </h2>
      )}
      {items.length === 0 ? (
        <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          {emptyMessage ?? 'Nothing here yet.'}
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-6 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {items.map((anime, i) => (
            <AnimeCard
              key={anime.id}
              anime={anime}
              rank={ranked ? i + 1 : undefined}
              status={statusOf(anime.id)}
              onStatusChange={onStatusChange}
            />
          ))}
        </div>
      )}
    </section>
  )
}
