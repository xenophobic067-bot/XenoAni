'use client'

import { useDeferredValue, useRef, useState } from 'react'
import { ChevronRight, Search } from 'lucide-react'
import type { Anime } from '@/lib/anilist'
import { useLibrary } from '@/hooks/use-library'
import { AppSidebar, type View } from '@/components/app-sidebar'
import { HeroBanner } from '@/components/hero-banner'
import { AnimeGrid } from '@/components/anime-grid'
import { SearchResults } from '@/components/search-results'
import { LibraryView } from '@/components/library/library-view'
import { cn } from '@/lib/utils'

type AnimeAppProps = {
  trending: Anime[]
  topRated: Anime[]
  popular: Anime[]
}

const VIEW_LABELS: Record<View, string> = {
  library: 'Library',
  overview: 'Overview',
  find: 'Find anime',
  watching: 'Watching',
  plan: 'Plan to Watch',
  completed: 'Completed',
}

const MOBILE_TABS: View[] = ['library', 'overview', 'find', 'watching', 'plan', 'completed']

export function AnimeApp({ trending, topRated, popular }: AnimeAppProps) {
  const [view, setView] = useState<View>('library')
  const [query, setQuery] = useState('')
  const deferredQuery = useDeferredValue(query.trim())
  const searchRef = useRef<HTMLInputElement>(null)
  const { entries, setStatus, statusOf, count } = useLibrary()

  const counts = { watching: count('watching'), plan: count('plan'), completed: count('completed') }
  const isSearching = deferredQuery.length >= 2
  const hasData = trending.length + topRated.length + popular.length > 0

  const navigate = (next: View) => {
    setView(next)
    if (next === 'find') requestAnimationFrame(() => searchRef.current?.focus())
    if (next !== 'find') setQuery('')
  }

  const libraryItems =
    view === 'watching' || view === 'plan' || view === 'completed'
      ? entries.filter((e) => e.status === view).map((e) => e.anime)
      : []

  return (
    <div className="flex min-h-dvh">
      <AppSidebar view={view} onNavigate={navigate} counts={counts} />

      <main className="min-w-0 flex-1 px-4 pb-16 sm:px-8 lg:px-12">
        <header className="flex items-center justify-between border-b py-5 text-xs">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-muted-foreground">
            <span>Library</span>
            <ChevronRight className="size-3.5" aria-hidden="true" />
            <span className="text-foreground">{VIEW_LABELS[view]}</span>
          </nav>
          <p className="flex items-center gap-2 text-muted-foreground">
            <span className="size-1.5 rounded-full bg-chart-3" aria-hidden="true" />
            Live from AniList
          </p>
        </header>

        <div className="mx-auto flex max-w-6xl flex-col gap-10 pt-8">
          <div className="flex flex-col gap-6">
            <div className="flex items-end justify-between gap-4">
              <div>
                <h1 className="text-3xl font-light tracking-tight sm:text-4xl">
                  XENO<span className="text-primary">ANI</span>
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">{"Naitik's anime world"}</p>
              </div>
              <p className="font-mono text-xs text-muted-foreground">{entries.length} titles</p>
            </div>

            <div className="relative max-w-xl">
              <Search
                className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                aria-hidden="true"
              />
              <label htmlFor="anime-search" className="sr-only">
                Search anime
              </label>
              <input
                ref={searchRef}
                id="anime-search"
                type="search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value)
                  if (view !== 'find' && view !== 'library' && e.target.value.trim()) setView('find')
                }}
                placeholder={view === 'library' ? 'Filter your library...' : 'Search anime...'}
                className="h-12 w-full rounded-xl border bg-card pl-11 pr-4 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>

            <div className="-mx-4 flex gap-2 overflow-x-auto px-4 lg:hidden" role="tablist" aria-label="Sections">
              {MOBILE_TABS.map((v) => (
                <button
                  key={v}
                  type="button"
                  role="tab"
                  aria-selected={view === v}
                  onClick={() => navigate(v)}
                  className={cn(
                    'shrink-0 rounded-full border px-3 py-1.5 text-xs transition-colors',
                    view === v ? 'border-primary bg-primary text-primary-foreground' : 'text-muted-foreground',
                  )}
                >
                  {VIEW_LABELS[v]}
                  {v in counts && ` · ${counts[v as keyof typeof counts]}`}
                </button>
              ))}
            </div>
          </div>

          {view === 'library' && <LibraryView query={query.trim()} />}

          {view === 'overview' && (
            <>
              {!hasData && (
                <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
                  {"Couldn't reach AniList right now. Refresh in a moment."}
                </p>
              )}
              <HeroBanner items={trending} statusOf={statusOf} onStatusChange={setStatus} />
              {topRated.length > 0 && (
                <AnimeGrid title="Top 10" items={topRated} ranked statusOf={statusOf} onStatusChange={setStatus} />
              )}
              {popular.length > 0 && (
                <AnimeGrid title="All-time popular" items={popular} statusOf={statusOf} onStatusChange={setStatus} />
              )}
            </>
          )}

          {view === 'find' &&
            (isSearching ? (
              <SearchResults query={deferredQuery} statusOf={statusOf} onStatusChange={setStatus} />
            ) : (
              <AnimeGrid
                title="Trending now"
                items={trending}
                statusOf={statusOf}
                onStatusChange={setStatus}
              />
            ))}

          {(view === 'watching' || view === 'plan' || view === 'completed') && (
            <AnimeGrid
              title={VIEW_LABELS[view]}
              items={libraryItems}
              statusOf={statusOf}
              onStatusChange={setStatus}
              emptyMessage="No titles yet. Hover any poster and use the buttons to add it here."
            />
          )}
        </div>
      </main>
    </div>
  )
}
