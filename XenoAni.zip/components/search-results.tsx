'use client'

import useSWR from 'swr'
import { Loader2 } from 'lucide-react'
import type { Anime } from '@/lib/anilist'
import type { LibraryStatus } from '@/hooks/use-library'
import { AnimeGrid } from '@/components/anime-grid'

const fetcher = (url: string) => fetch(url).then((r) => r.json() as Promise<{ results: Anime[] }>)

type SearchResultsProps = {
  query: string
  statusOf: (id: number) => LibraryStatus | null
  onStatusChange: (anime: Anime, status: LibraryStatus | null) => void
}

export function SearchResults({ query, statusOf, onStatusChange }: SearchResultsProps) {
  const { data, isLoading } = useSWR(`/api/search?q=${encodeURIComponent(query)}`, fetcher, {
    keepPreviousData: true,
  })

  if (isLoading && !data) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status">
        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
        Searching AniList...
      </p>
    )
  }

  return (
    <AnimeGrid
      title={`Results for "${query}"`}
      items={data?.results ?? []}
      statusOf={statusOf}
      onStatusChange={onStatusChange}
      emptyMessage="No anime matched your search."
    />
  )
}
