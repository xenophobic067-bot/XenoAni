'use client'

import Image from 'next/image'
import { Check, Clock, Play, Star } from 'lucide-react'
import type { Anime } from '@/lib/anilist'
import type { LibraryStatus } from '@/hooks/use-library'
import { cn } from '@/lib/utils'

const STATUS_ACTIONS: { status: LibraryStatus; label: string; icon: typeof Play }[] = [
  { status: 'watching', label: 'Watching', icon: Play },
  { status: 'plan', label: 'Plan to watch', icon: Clock },
  { status: 'completed', label: 'Completed', icon: Check },
]

type AnimeCardProps = {
  anime: Anime
  rank?: number
  status: LibraryStatus | null
  onStatusChange: (anime: Anime, status: LibraryStatus | null) => void
  priority?: boolean
}

export function AnimeCard({ anime, rank, status, onStatusChange, priority }: AnimeCardProps) {
  return (
    <article className="group flex flex-col gap-3">
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-card ring-1 ring-border">
        <Image
          src={anime.cover || '/placeholder.svg'}
          alt={`${anime.title} cover art`}
          fill
          priority={priority}
          sizes="(min-width: 1280px) 200px, (min-width: 768px) 25vw, 45vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent opacity-90" />

        {rank !== undefined && (
          <span className="absolute left-2 top-2 flex size-8 items-center justify-center rounded-lg bg-background/80 font-mono text-sm font-semibold text-primary backdrop-blur">
            {rank}
          </span>
        )}
        {anime.score !== null && (
          <span className="absolute right-2 top-2 flex items-center gap-1 rounded-md bg-background/80 px-1.5 py-1 text-xs font-medium backdrop-blur">
            <Star className="size-3 fill-chart-2 text-chart-2" aria-hidden="true" />
            {(anime.score / 10).toFixed(1)}
          </span>
        )}

        <div className="absolute inset-x-2 bottom-2 flex gap-1.5 opacity-100 transition-opacity md:opacity-0 md:group-hover:opacity-100 md:group-focus-within:opacity-100">
          {STATUS_ACTIONS.map(({ status: s, label, icon: Icon }) => {
            const active = status === s
            return (
              <button
                key={s}
                type="button"
                onClick={() => onStatusChange(anime, active ? null : s)}
                aria-pressed={active}
                aria-label={`${active ? 'Remove from' : 'Mark as'} ${label}: ${anime.title}`}
                title={label}
                className={cn(
                  'flex h-8 flex-1 items-center justify-center rounded-lg backdrop-blur transition-colors',
                  active
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-background/80 text-foreground hover:bg-secondary',
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
              </button>
            )
          })}
        </div>
      </div>

      <div className="min-w-0">
        <h3 className="truncate text-sm font-medium text-foreground">{anime.title}</h3>
        <p className="mt-0.5 truncate text-xs text-muted-foreground">
          {[anime.format?.replace('_', ' '), anime.year, anime.episodes ? `${anime.episodes} eps` : null]
            .filter(Boolean)
            .join(' · ')}
        </p>
      </div>
    </article>
  )
}
