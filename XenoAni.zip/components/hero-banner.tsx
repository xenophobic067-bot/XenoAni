'use client'

import Image from 'next/image'
import { useState } from 'react'
import { Plus, Star } from 'lucide-react'
import type { Anime } from '@/lib/anilist'
import type { LibraryStatus } from '@/hooks/use-library'
import { cn } from '@/lib/utils'

type HeroBannerProps = {
  items: Anime[]
  statusOf: (id: number) => LibraryStatus | null
  onStatusChange: (anime: Anime, status: LibraryStatus | null) => void
}

export function HeroBanner({ items, statusOf, onStatusChange }: HeroBannerProps) {
  const featured = items.filter((a) => a.banner).slice(0, 5)
  const [index, setIndex] = useState(0)
  const anime = featured[index]

  if (!anime) return null

  const inLibrary = statusOf(anime.id) !== null

  return (
    <section aria-label="Trending now" className="relative overflow-hidden rounded-2xl ring-1 ring-border">
      <div className="relative aspect-[16/10] w-full sm:aspect-[21/9]">
        <Image
          key={anime.id}
          src={anime.banner ?? anime.cover}
          alt=""
          fill
          priority
          sizes="(min-width: 1024px) 1100px, 100vw"
          className="object-cover animate-in fade-in duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
      </div>

      <div className="absolute inset-0 flex items-end gap-6 p-5 sm:p-8">
        <div className="relative hidden aspect-[2/3] w-32 shrink-0 overflow-hidden rounded-xl shadow-2xl ring-1 ring-border md:block lg:w-40">
          <Image src={anime.cover || '/placeholder.svg'} alt={`${anime.title} cover art`} fill sizes="160px" className="object-cover" />
        </div>

        <div className="flex max-w-xl flex-col gap-3">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Trending #{index + 1}</p>
          <h2 className="text-balance text-2xl font-semibold leading-tight sm:text-4xl">{anime.title}</h2>
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            {anime.score !== null && (
              <span className="flex items-center gap-1 text-foreground">
                <Star className="size-3.5 fill-chart-2 text-chart-2" aria-hidden="true" />
                {(anime.score / 10).toFixed(1)}
              </span>
            )}
            {anime.genres.slice(0, 3).map((g) => (
              <span key={g} className="rounded-full bg-secondary/80 px-2 py-0.5 backdrop-blur">
                {g}
              </span>
            ))}
          </div>
          <p className="line-clamp-2 text-pretty text-sm leading-relaxed text-muted-foreground sm:line-clamp-3">
            {anime.description}
          </p>
          <div className="flex items-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onStatusChange(anime, inLibrary ? null : 'plan')}
              className="flex h-9 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              <Plus className={cn('size-4 transition-transform', inLibrary && 'rotate-45')} aria-hidden="true" />
              {inLibrary ? 'In library' : 'Add to library'}
            </button>
            <div className="flex items-center gap-1.5" role="tablist" aria-label="Featured anime">
              {featured.map((a, i) => (
                <button
                  key={a.id}
                  type="button"
                  role="tab"
                  aria-selected={i === index}
                  aria-label={a.title}
                  onClick={() => setIndex(i)}
                  className={cn(
                    'h-1.5 rounded-full transition-all',
                    i === index ? 'w-6 bg-primary' : 'w-1.5 bg-foreground/30 hover:bg-foreground/60',
                  )}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
