'use client'

import useSWR from 'swr'
import type { Anime } from '@/lib/anilist'

export type LibraryStatus = 'watching' | 'plan' | 'completed'

export type LibraryEntry = { anime: Anime; status: LibraryStatus }

const KEY = 'xenoani-library'

export function useLibrary() {
  const { data: entries = [], mutate } = useSWR<LibraryEntry[]>(KEY, null, {
    fallbackData: [],
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  })

  const setStatus = (anime: Anime, status: LibraryStatus | null) => {
    mutate(
      (current = []) => {
        const rest = current.filter((e) => e.anime.id !== anime.id)
        return status ? [{ anime, status }, ...rest] : rest
      },
      { revalidate: false },
    )
  }

  const statusOf = (id: number) => entries.find((e) => e.anime.id === id)?.status ?? null

  const count = (status: LibraryStatus) => entries.filter((e) => e.status === status).length

  return { entries, setStatus, statusOf, count }
}
