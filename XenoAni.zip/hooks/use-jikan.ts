'use client'

import { useEffect, useSyncExternalStore } from 'react'
import { getServerSnapshot, getSnapshot, prefetchTitles, retryFailed, subscribe } from '@/lib/jikan'

export function useJikan(titles: string[]) {
  const cache = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)

  useEffect(() => {
    void prefetchTitles(titles)
  }, [titles])

  const loaded = titles.filter((t) => t in cache).length
  const failed = titles.filter((t) => cache[t] === null).length

  return { cache, loaded, failed, total: titles.length, retry: () => retryFailed(titles) }
}
