import { searchAnime } from '@/lib/anilist'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const q = (searchParams.get('q') ?? '').trim().slice(0, 100)
  if (q.length < 2) return Response.json({ results: [] })
  const results = await searchAnime(q)
  return Response.json({ results })
}
