const QUERY = `query ($search: String) {
  Media(search: $search, type: ANIME) {
    id idMal siteUrl
    title { romaji english }
    coverImage { extraLarge large }
    averageScore episodes format seasonYear status genres description(asHtml: false)
  }
}`

export async function GET(request: Request) {
  const q = (new URL(request.url).searchParams.get('q') ?? '').trim().slice(0, 120)
  if (q.length < 2) return Response.json({ error: 'Missing query' }, { status: 400 })

  const res = await fetch('https://graphql.anilist.co', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query: QUERY, variables: { search: q } }),
    next: { revalidate: 60 * 60 * 24 },
  }).catch(() => null)

  if (!res) return Response.json({ error: 'Upstream unreachable' }, { status: 502 })
  if (res.status === 404) return Response.json({ anime: null })
  if (!res.ok) return Response.json({ error: 'Upstream error' }, { status: res.status === 429 ? 429 : 502 })

  const json = await res.json()
  const m = json?.data?.Media
  if (!m) return Response.json({ anime: null })

  return Response.json({
    anime: {
      malId: m.idMal ?? m.id,
      title: m.title.romaji ?? m.title.english ?? q,
      titleEnglish: m.title.english,
      image: m.coverImage.extraLarge ?? m.coverImage.large ?? null,
      episodes: m.episodes,
      score: m.averageScore != null ? m.averageScore / 10 : null,
      synopsis: m.description ? m.description.replace(/<[^>]+>/g, '').replace(/\n{3,}/g, '\n\n').trim() : null,
      genres: m.genres ?? [],
      type: m.format?.replace(/_/g, ' ') ?? null,
      year: m.seasonYear,
      status: m.status,
      url: m.idMal ? `https://myanimelist.net/anime/${m.idMal}` : m.siteUrl,
    },
  })
}
