import { AnimeApp } from '@/components/anime-app'
import { getPopular, getTopRated, getTrending } from '@/lib/anilist'

export default async function Page() {
  const [trending, topRated, popular] = await Promise.all([getTrending(10), getTopRated(10), getPopular(10)])

  return <AnimeApp trending={trending} topRated={topRated} popular={popular} />
}
